# INFLUENZERS — Static Export

This folder is a self-contained static build of the INFLUENZERS site. All HTML, JS, CSS, fonts, images, and the Arabic logo are bundled inside. No server, database, or environment variables are required.

## Deploy to GitHub Pages

1. Create a new GitHub repository.
2. Copy the entire contents of this folder to the repository root (or to a `docs/` folder).
3. Push to GitHub.
4. In the repo: **Settings → Pages → Build and deployment → Source: Deploy from a branch**, select your branch and `/ (root)` or `/docs` depending on where you placed the files.
5. GitHub will publish the site at `https://<user>.github.io/<repo>/`.

`404.html` is included as an SPA fallback so client-side routes (`/terms-of-service`, `/privacy-policy`, `/creator-terms`) work correctly on refresh or direct visit.

## Deploy anywhere else

Upload the folder contents to any static host — Netlify, Vercel, Cloudflare Pages, S3 + CloudFront, Nginx, etc. If your host does not automatically serve `404.html` for unknown paths, configure a SPA fallback that rewrites unknown paths to `/index.html`.

## Notes

- Default language is auto-detected from the browser (Arabic or English).
- The language switcher persists the user's choice in `localStorage`.
- All third-party links (Dolphinuz, VYV Live, Fillout intake form, social) open in new tabs.
